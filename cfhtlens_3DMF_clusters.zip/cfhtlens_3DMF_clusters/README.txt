The following catalogues contain the publically available 3D-Matched-Filter 
(3DMF) Galaxy Cluster candidates in the 4 fields of CFHTLenS:

cfhtlens_3DMF_clusters_W1.cat
cfhtlens_3DMF_clusters_W2.cat
cfhtlens_3DMF_clusters_W3.cat
cfhtlens_3DMF_clusters_W4.cat

Each catalogue contains 4 columns: right ascension (RA), declination (DEC),
redshift (z), and 3D-MF detection significance (sig). 

As discussed in the references below, sig has been found to scale well
with mass. While these catalogues contain all clusters detected at 
sig > 3.5, we expect there to be significant false detections at the lower
end of this. Depending on your application, you may find it useful to make
a cut at perhaps sig > 5 or 10. The position of the cluster (RA, DEC) is
coincident with the peak in the 3DMF likelihood map, and does NOT 
necessarily coincide with a member galaxy. Redshift z is the center of the 
3DMF redshift bin that maximizes a cluster detection, and has not been 
refined to more precise values than the binning employed by the 3DMF 
algorithm. For more details, please consult the references given below.


Details of the 3DMF algorithm can be found in:
Milkeraitis et al. 2010 
http://arxiv.org/abs/0912.0739

The specifics of the 3DMF application to the CFHTLenS fields is here:
Ford et al. 2014a
http://arxiv.org/abs/1310.2295
and
Ford et al. 2014b
http://arxiv.org/abs/????????


If you have any questions about these catalogues, please contact:
Jes Ford: jesford@phas.ubc.ca
Ludovic Van Waerbeke: waerbeke@phas.ubc.ca

